import { useEffect } from 'react';

export function useScrollLockX() {
  useEffect(() => {
    const disableScrollX = () => {
      document.body.style.overflowX = 'hidden';
    };

    const enableScrollX = () => {
      document.body.style.overflowX = '';
    };

    disableScrollX();

    return () => enableScrollX();
  }, []);
}
