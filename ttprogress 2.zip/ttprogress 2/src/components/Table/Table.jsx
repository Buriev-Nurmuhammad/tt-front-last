import React from 'react'

const Table = () => {
  return (
    <div>
      
    </div>
  )
}

export default Table
