import React, { useEffect, useState } from "react"
import { testimonal } from "../../../dummydata"
import Heading from "../../common/heading/Heading"
import { useTranslation } from "react-i18next";
import "./style.css"
import { Carousel } from "@trendyol-js/react-carousel";

const Testimonal = () => {

  const [showSlides, setShowSlides] = useState(8);
  const [logos, setLogos] = useState([]);
  const [loading, setLoading] = useState(true);
  const { t, i18n } = useTranslation();

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 768) {
        setShowSlides(2);
      } else {
        setShowSlides(7);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <>
      <section className='testimonal padding'>
        <div className='container'>
          

          {/* <div className='content grid2'>
            {testimonal.map((val) => (
              <div className='items shadow'>
                <div className='box flex'>
                  <div className='img'>
                    <img src={val.cover} alt='' />
                    <i className='fa fa-quote-left icon'></i>
                  </div>
                  <div className='name'>
                    <h2>{val.name}</h2>
                    <span>{val.post}</span>
                  </div>
                </div>
                <p>{val.desc}</p>
              </div>
            ))}
          </div> */}
           <Carousel
          className="exampleCarousel1"
          show={showSlides}
          slide={1}
          swiping={true}
          autoSwipe={2000}
          leftArrow={false}
          rightArrow={false}
          responsive={true}
          infinite={true}
        >
          <div className='content grid2'>
            {testimonal.map((val) => (
              <div className='items shadow'>
                <div className='box flex'>
                  <div className='img'>
                    <img src={val.cover} alt='' />
                    <i className='fa fa-quote-left icon'></i>
                  </div>
                  <div className='name'>
                    <h2>{val.name}</h2>
                    <span>{val.post}</span>
                  </div>
                </div>
                <p>{val.desc}</p>
              </div>
            ))}
          </div>
        </Carousel>
        </div>
      </section>
    </>
  )
}

export default Testimonal
